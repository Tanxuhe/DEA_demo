# main_verify.py
import config
from src.data_generator import DataGenerator
from src.models.milp_direct import MilpDirect
from src.algorithms.benders import BendersSolver # 新增引入
import os

def run_step_0():
    print("=== STEP 0: 验证阶段启动 ===")
    
    # 1. 生成数据
    print(f"\n[1] Generating Synthetic Data (K={config.K}, O={config.O_TOTAL})...")
    gen = DataGenerator(K=config.K, I=config.I, O=config.O_TOTAL, seed=config.RANDOM_SEED)
    X, Y = gen.generate_cobb_douglas()
    
    # ----------------------------------------------------
    # Method A: Gurobi Direct MILP
    # ----------------------------------------------------
    print(f"\n[2] Solving with Direct MILP (Benchmark)...")
    milp_model = MilpDirect(X, Y, p=config.P_SELECT, time_limit=config.TIME_LIMIT)
    res_milp = milp_model.build_and_solve()
    
    if res_milp['status'] != 'Optimal':
        print("❌ MILP求解失败，终止验证。")
        return

    # ----------------------------------------------------
    # Method B: Benders Decomposition
    # ----------------------------------------------------
    print(f"\n[3] Solving with Benders Decomposition...")
    benders = BendersSolver(X, Y, p=config.P_SELECT, time_limit=config.TIME_LIMIT)
    res_benders = benders.solve()

    # ----------------------------------------------------
    # 结果对比
    # ----------------------------------------------------
    print("\n" + "="*50)
    print("FINAL VALIDATION REPORT")
    print("="*50)
    
    obj_milp = res_milp['obj_val']
    obj_benders = res_benders['obj_val']
    diff = abs(obj_milp - obj_benders)
    
    feat_milp = sorted(res_milp['selected_features'])
    feat_benders = sorted(res_benders['selected_features'])
    
    print(f"{'Metric':<20} | {'Direct MILP':<15} | {'Benders':<15}")
    print("-" * 55)
    print(f"{'Objective':<20} | {obj_milp:.6f}        | {obj_benders:.6f}")
    print(f"{'Selected Features':<20} | {str(feat_milp):<15} | {str(feat_benders):<15}")
    print(f"{'Time (s)':<20} | {res_milp['time']:.4f}          | {res_benders['time']:.4f}")
    print("-" * 55)
    
    # 自动判定
    if diff < 1e-4 and feat_milp == feat_benders:
        print("✅ 验证成功! Benders 结果与 Gurobi 完全一致。")
        print("下一步计划:")
        print("1. 进入 Step 1 (调优): 增大 K 值，观察 Benders 迭代次数。")
        print("2. 引入 Combinatorial Cuts 加速收敛。")
        print("3. 将子问题改为并行计算。")
    else:
        print("❌ 验证失败! 结果不一致，请检查 Subproblem 对偶推导或 Cut 公式。")

if __name__ == "__main__":
    run_step_0()