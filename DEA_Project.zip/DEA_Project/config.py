# config.py

# === 实验规模设置 ===
K = 50          # DMU数量 (Step 0 用50个验证，Step 2再加大)
I = 2           # 投入(Input)数量
O_TOTAL = 20    # 潜在产出(Features)总数
P_SELECT = 3    # 需要选出的特征数量 (p)

# === 数据生成参数 ===
RANDOM_SEED = 42
NOISE_LEVEL = 0.5  # 半正态分布的噪音强度

# === 求解器参数 ===
TIME_LIMIT = 300   # 秒
MIP_GAP = 0.0001   # 收敛精度