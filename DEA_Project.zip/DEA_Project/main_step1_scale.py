# main_step1_scale.py
import config
from src.data_generator import DataGenerator
# from src.models.milp_direct import MilpDirect  # <--- 注释掉，不加载它了
from src.algorithms.benders_parallel import ParallelBendersSolver
import time
import sys

def run_scale_experiment():
    # === 实验配置 ===
    K_LARGE = 2000      # 保持 2000
    O_LARGE = 50        
    P_LARGE = 5         
    TIME_LIMIT = 3600    
    
    print(f"=== STEP 1: 扩规模实验 (K={K_LARGE}, O={O_LARGE}, p={P_LARGE}) ===")
    
    # 1. 生成数据
    print("[1] Generating Large Synthetic Data...")
    gen = DataGenerator(K=K_LARGE, I=2, O=O_LARGE, seed=42)
    X, Y = gen.generate_cobb_douglas()
    
    # 2. 运行 Gurobi Direct MILP (跳过)
    print("\n[2] Skipping Direct MILP (Proven to crash due to OOM at K=2000)...")
    # milp = MilpDirect(X, Y, p=P_LARGE, time_limit=TIME_LIMIT)
    # res_milp = milp.build_and_solve()
    
    # 3. 运行 Parallel Benders
    print("\n[3] Running Parallel Benders...")
    print(f"    (Using {config.I} inputs, {config.O_TOTAL} potential outputs)")
    
    # 记录 Benders 的内存和时间应该是极低的
    pb = ParallelBendersSolver(X, Y, p=P_LARGE, time_limit=TIME_LIMIT)
    
    try:
        res_pb = pb.solve()
        
        # 4. 输出结果
        print("\n" + "="*60)
        print(f"SCALE EXPERIMENT RESULTS (K={K_LARGE})")
        print("="*60)
        
        print(f"Status:       {res_pb['status']}")
        print(f"Objective:    {res_pb['obj_val']:.6f}")
        print(f"Time (s):     {res_pb['time']:.4f}")
        print(f"Iterations:   {res_pb['iterations']}")
        print(f"Features:     {res_pb['selected_features']}")
        print("-" * 60)
        print("✅ Benders 成功运行！证明了在大规模数据下的可行性。")
        
    except Exception as e:
        print(f"❌ Benders 也报错了: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    run_scale_experiment()