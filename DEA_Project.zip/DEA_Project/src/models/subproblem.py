# src/models/subproblem.py
import gurobipy as gp
from gurobipy import GRB

def solve_subproblem(k, X, Y, z_bar, K, I, O):
    """
    求解单个DMU的子问题 (Primal Form)，并返回对偶信息。
    
    参数:
    k: 当前计算的DMU索引
    X, Y: 数据矩阵
    z_bar: 主问题传递过来的当前特征选择方案 (list or array of 0/1)
    K, I, O: 维度信息
    
    返回:
    dict: 包含效率值(obj), 以及用于构造Cut的对偶变量(u, w)
    """
    
    # 1. 建立模型 (Max Efficiency)
    model = gp.Model(f"SP_{k}")
    model.setParam('OutputFlag', 0) # 静默模式
    
    # 变量
    alpha = model.addVars(I, lb=0.0, name="alpha")
    beta = model.addVars(O, lb=0.0, name="beta")
    
    # 目标: Maximize Efficiency of DMU k
    # Efficiency = sum(beta_o * y_ko)
    model.setObjective(
        gp.quicksum(beta[o] * Y[k, o] for o in range(O)), 
        GRB.MAXIMIZE
    )
    
    # --- 约束 ---
    
    # (C1) 归一化约束: sum(alpha * x_k) = 1
    # 对应对偶变量 u_k
    c_norm = model.addConstr(
        gp.quicksum(alpha[i] * X[k, i] for i in range(I)) == 1, 
        name="Norm"
    )
    
    # (C2) 包络约束: sum(beta * y_j) - sum(alpha * x_j) <= 0
    # 对应对偶变量 v_kj (虽然构造Cut不需要直接用v，但必须有这个约束)
    for j in range(K):
        model.addConstr(
            gp.quicksum(beta[o] * Y[j, o] for o in range(O)) - 
            gp.quicksum(alpha[i] * X[j, i] for i in range(I)) <= 0,
            name=f"Peer_{j}"
        )
        
    # (C3) 特征选择约束 (Big-M / Tight-M)
    # beta_o <= M * z_bar_o
    # 对应对偶变量 w_ko (关键!)
    c_bigm = {}
    M_vals = {} # 存储M值，用于返回给主问题构造Cut
    
    for o in range(O):
        # 计算 Tight M = 1 / y_ko
        M_tight = 1.0 / Y[k, o] if Y[k, o] > 1e-6 else 0
        M_vals[o] = M_tight
        
        # 即使 z_bar[o] == 1, 我们也要加这个约束, 
        # 否则无法获得 beta 达到上限时的影子价格
        rhs_val = M_tight * z_bar[o]
        c_bigm[o] = model.addConstr(beta[o] <= rhs_val, name=f"BigM_{o}")

    # 2. 求解
    model.optimize()
    
    # 3. 提取结果
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        
        # 提取对偶变量 (Shadow Prices)
        # Gurobi中: Pi 是约束的对偶值
        u_val = c_norm.Pi
        
        # w_val: 注意Gurobi对于 <= 约束, Pi通常为正 (代表放宽RHS能增加目标值)
        w_vals = [c_bigm[o].Pi for o in range(O)]
        
        return {
            'status': 'Optimal',
            'obj': obj_val,
            'u': u_val,
            'w': w_vals,
            'M': list(M_vals.values()) # 必须把M传回去，保证Cut的一致性
        }
    else:
        # 理论上DEA子问题对于有效数据总是有解的 (效率<=1)
        # 如果不可行，通常是数据问题
        return {'status': 'Infeasible', 'obj': 0.0}