# src/models/milp_direct.py
import gurobipy as gp
from gurobipy import GRB
import numpy as np

class MilpDirect:
    def __init__(self, X, Y, p, time_limit=300):
        self.X = X
        self.Y = Y
        self.p = p
        self.K, self.I = X.shape
        self.O = Y.shape[1]
        self.time_limit = time_limit
        self.model = None

    def build_and_solve(self):
        """
        构建并求解论文中的 Joint Selection Model (3.1节)
        """
        m = gp.Model("DEA_Feature_Selection_MILP")
        m.setParam('TimeLimit', self.time_limit)
        m.setParam('MIPGap', 0.0001)
        m.setParam('OutputFlag', 1) # 1: 打印日志, 0: 静默

        # --- 1. 变量定义 ---
        # z[o]: 全局特征选择变量 (Binary)
        z = m.addVars(self.O, vtype=GRB.BINARY, name="z")

        # alpha[k, i]: 第k个DMU的第i个投入权重
        alpha = m.addVars(self.K, self.I, lb=0.0, vtype=GRB.CONTINUOUS, name="alpha")

        # beta[k, o]: 第k个DMU的第o个产出权重
        beta = m.addVars(self.K, self.O, lb=0.0, vtype=GRB.CONTINUOUS, name="beta")

        # --- 2. 目标函数: 最大化平均效率 ---
        # E_k = sum(beta[k,o] * y[k,o])
        avg_efficiency = gp.quicksum(
            beta[k, o] * self.Y[k, o] 
            for k in range(self.K) for o in range(self.O)
        )
        m.setObjective(avg_efficiency / self.K, GRB.MAXIMIZE)

        # --- 3. 约束条件 ---
        
        # (Constraint 26): 必须选 p 个特征
        m.addConstr(z.sum() == self.p, name="Select_p_Features")

        for k in range(self.K):
            # (Constraint 21): 归一化约束 sum(alpha * x) = 1
            lhs_norm = gp.quicksum(alpha[k, i] * self.X[k, i] for i in range(self.I))
            m.addConstr(lhs_norm == 1, name=f"Norm_DMU_{k}")

            # (Constraint 25): Big-M (Tight M) 约束
            # beta_{k,o} <= (1/y_{k,o}) * z_o
            # 这里的 1/y 就是非常紧的 M 值
            for o in range(self.O):
                M_tight = 1.0 / self.Y[k, o] if self.Y[k, o] > 1e-6 else 0
                m.addConstr(beta[k, o] <= M_tight * z[o], name=f"BigM_{k}_{o}")

            # (Constraint 20): DEA 包络约束 (对于每个 DMU j)
            # sum(beta * y_j) - sum(alpha * x_j) <= 0
            # 这是 O(K^2) 复杂度的来源
            for j in range(self.K):
                out_score = gp.quicksum(beta[k, o] * self.Y[j, o] for o in range(self.O))
                inp_score = gp.quicksum(alpha[k, i] * self.X[j, i] for i in range(self.I))
                m.addConstr(out_score - inp_score <= 0, name=f"Peer_{k}_{j}")

        # --- 4. 求解 ---
        print(f"\n[INFO] Starting Gurobi Solve for K={self.K}, O={self.O}...")
        m.optimize()

        # --- 5. 结果提取 ---
        result = {}
        if m.status == GRB.OPTIMAL:
            result['status'] = 'Optimal'
            result['obj_val'] = m.ObjVal
            # 提取选中的特征索引
            selected_features = [o for o in range(self.O) if z[o].X > 0.5]
            result['selected_features'] = selected_features
            result['gap'] = m.MIPGap
            result['time'] = m.Runtime
        else:
            result['status'] = 'Infeasible/Unbounded'
        
        return result