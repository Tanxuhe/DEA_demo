# src/data_generator.py
import numpy as np
import pandas as pd

class DataGenerator:
    def __init__(self, K, I, O, seed=42):
        self.K = K  # DMU数量
        self.I = I  # 投入数量
        self.O = O  # 潜在产出数量
        self.rng = np.random.default_rng(seed)

    def generate_cobb_douglas(self):
        """
        生成模拟DEA数据
        返回: 
            X (K x I): 投入矩阵
            Y (K x O): 产出矩阵 (包含真实产出 + 噪音产出)
        """
        # 1. 生成投入 X (均匀分布 [10, 100])
        X = self.rng.uniform(10, 100, (self.K, self.I))

        # 2. 定义真实的生产函数 (Cobb-Douglas)
        # Y_true = 5 * x1^0.5 * x2^0.5 ...
        # 这里假设只有前2个投入起作用，简化处理
        scale_factor = 5.0
        elasticity = 0.5 / self.I 
        Y_basis = scale_factor * np.prod(X ** elasticity, axis=1)

        # 3. 生成无效率因子 (Inefficiency) -> 真实产出
        # 效率值 eff = exp(-u), u ~ |N(0, 0.2)|
        u = np.abs(self.rng.normal(0, 0.2, self.K))
        efficiency = np.exp(-u)
        Y_true = Y_basis * efficiency

        # 4. 构建特征池 (100个特征)
        Y_pool = np.zeros((self.K, self.O))

        # [Type A] 真实信号 (前 20% 的特征)
        n_real = max(1, int(self.O * 0.2))
        for o in range(n_real):
            # 在真实产出上加一点点观测噪音
            noise = self.rng.normal(0, 0.05 * np.mean(Y_true), self.K)
            Y_pool[:, o] = np.maximum(0.1, Y_true + noise)

        # [Type B] 高度相关特征 (模拟多重共线性)
        n_corr = max(1, int(self.O * 0.3))
        for o in range(n_real, n_real + n_corr):
            # 复制 Type A 的特征并加上扰动
            ref_idx = self.rng.integers(0, n_real)
            perturbation = self.rng.normal(0, 0.1 * np.mean(Y_pool[:, ref_idx]), self.K)
            Y_pool[:, o] = np.maximum(0.1, Y_pool[:, ref_idx] + perturbation)

        # [Type C] 纯噪音/无关特征 (剩下的)
        for o in range(n_real + n_corr, self.O):
            Y_pool[:, o] = self.rng.uniform(10, 100, self.K)

        return X, Y_pool