# src/algorithms/benders.py
import gurobipy as gp
from gurobipy import GRB
import time
# 引入刚才写的子问题函数
from src.models.subproblem import solve_subproblem

class BendersSolver:
    def __init__(self, X, Y, p, time_limit=300, max_iter=100):
        self.X = X
        self.Y = Y
        self.p = p
        self.K, self.I = X.shape
        self.O = Y.shape[1]
        self.time_limit = time_limit
        self.max_iter = max_iter
        
        # 记录
        self.ub_history = []
        self.lb_history = []
        
    def solve(self):
        start_time = time.time()
        
        # --- 1. 初始化主问题 (Master Problem) ---
        mp = gp.Model("Benders_Master")
        mp.setParam('OutputFlag', 0) # 减少刷屏
        
        # 变量 z: 特征选择
        z = mp.addVars(self.O, vtype=GRB.BINARY, name="z")
        
        # 变量 theta: 预估的每个DMU的效率
        # theta_k <= 1 (因为DEA效率上限是1)
        theta = mp.addVars(self.K, lb=0.0, ub=1.0, vtype=GRB.CONTINUOUS, name="theta")
        
        # 目标: Maximize Average Theta
        mp.setObjective(theta.sum() / self.K, GRB.MAXIMIZE)
        
        # 约束: 选 p 个
        mp.addConstr(z.sum() == self.p, name="Select_p")
        
        # [可选] 初始解: 先随便给一个，比如选前p个
        # 这有助于第一轮产生的Cut稍微有点意义，或者让主问题快速有解
        # 这里暂时留空，让Gurobi自己定初始z
        
        # --- 2. Benders 主循环 ---
        best_z = None
        global_lb = -1e10 # 下界 (真实效率)
        global_ub = 1e10  # 上界 (主问题预估)
        
        print(f"{'Iter':<5} | {'Master(UB)':<12} | {'Sub(LB)':<12} | {'Gap(%)':<8} | {'Time(s)':<8}")
        print("-" * 55)
        
        for iteration in range(1, self.max_iter + 1):
            
            # A. 求解主问题
            mp.optimize()
            
            if mp.status != GRB.OPTIMAL:
                print("Master problem infeasible or failed.")
                break
                
            current_ub = mp.ObjVal
            # 获取当前的特征方案 (0/1)
            z_curr = [1 if z[o].X > 0.5 else 0 for o in range(self.O)]
            
            # B. 求解子问题 (Subproblems)
            # Step 0: 串行求解 (Verify阶段)
            # Step 2: 将改为并行
            
            total_true_efficiency = 0
            cuts_info = [] # 存储生成Cut所需的信息
            
            for k in range(self.K):
                # 调用子问题函数
                sp_res = solve_subproblem(
                    k, self.X, self.Y, z_curr, self.K, self.I, self.O
                )
                
                if sp_res['status'] != 'Optimal':
                    raise ValueError(f"Subproblem {k} failed!")
                
                real_eff = sp_res['obj']
                total_true_efficiency += real_eff
                cuts_info.append((k, sp_res))
            
            current_lb = total_true_efficiency / self.K
            
            # 更新全局边界
            global_ub = min(global_ub, current_ub) # 上界是非递增的吗？通常是
            global_lb = max(global_lb, current_lb) # 我们要找最好的下界
            
            # 记录最佳解
            if current_lb >= global_lb:
                best_z = [o for o in range(self.O) if z_curr[o] == 1]
            
            elapsed = time.time() - start_time
            gap = (global_ub - global_lb) / abs(global_lb) if global_lb > 1e-6 else 1.0
            
            print(f"{iteration:<5} | {current_ub:.6f}     | {current_lb:.6f}     | {gap*100:.4f}%  | {elapsed:.2f}")
            
            # C. 检查收敛
            if gap < 1e-4 or elapsed > self.time_limit:
                print("Converged!")
                break
            
            # D. 添加 Benders Cuts
            # Cut 形式: theta_k <= u_k + sum( M_{ko} * w_{ko} * z_o )
            
            added_cuts = 0
            for k, res in cuts_info:
                # 只有当主问题的预估值 theta_k 明显大于真实值时才加 Cut
                # (Optimality Cut)
                theta_val = theta[k].X
                real_val = res['obj']
                
                if theta_val > real_val + 1e-5:
                    u_val = res['u']
                    w_vals = res['w']
                    M_vals = res['M']
                    
                    # 构建线性表达式: sum( M * w * z )
                    # 注意: w_vals[o] 是 shadow price
                    expr = gp.quicksum(
                        (M_vals[o] * w_vals[o]) * z[o] 
                        for o in range(self.O)
                        if w_vals[o] > 1e-6 # 只加非零项，减少稀疏性
                    )
                    
                    mp.addConstr(theta[k] <= u_val + expr, name=f"Cut_{iteration}_{k}")
                    added_cuts += 1
            
            # 如果没有加任何Cut，也说明收敛了
            if added_cuts == 0:
                print("No cuts added. Converged.")
                break
                
        return {
            'status': 'Optimal',
            'obj_val': global_lb,
            'selected_features': sorted(best_z) if best_z else [],
            'time': time.time() - start_time,
            'iterations': iteration
        }