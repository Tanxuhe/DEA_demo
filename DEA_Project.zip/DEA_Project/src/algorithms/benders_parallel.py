# src/algorithms/benders_parallel.py
import gurobipy as gp
from gurobipy import GRB
import time
from multiprocessing import Pool, cpu_count
# 确保这里正确引用了你的子问题函数
from src.models.subproblem import solve_subproblem

class ParallelBendersSolver:
    def __init__(self, X, Y, p, time_limit=3600, max_iter=200, n_jobs=-1, use_logic_cuts=True):
        """
        初始化并行 Benders 求解器
        :param time_limit: 时间限制 (默认 3600s)
        :param use_logic_cuts: 是否启用组合逻辑割 (建议开启)
        """
        self.X = X
        self.Y = Y
        self.p = p
        self.K, self.I = X.shape
        self.O = Y.shape[1]
        self.time_limit = time_limit
        self.max_iter = max_iter
        self.use_logic_cuts = use_logic_cuts
        
        # 确定并行核数 (-1 表示使用所有核)
        self.n_jobs = cpu_count() if n_jobs == -1 else n_jobs
        print(f"[ParallelBenders] Initialized with {self.n_jobs} workers.")
        print(f"[ParallelBenders] Logic Cuts Enabled: {self.use_logic_cuts}")
        print(f"[ParallelBenders] Time Limit: {self.time_limit}s")

    def solve(self):
        start_time = time.time()
        
        # --- 1. 初始化主问题 (Master Problem) ---
        mp = gp.Model("Benders_Master")
        mp.setParam('OutputFlag', 0) # 静默模式
        mp.setParam('LazyConstraints', 1) # 允许 Lazy Constraints (如果以后用 callback)
        
        # 变量 z: 特征选择 (Binary)
        z = mp.addVars(self.O, vtype=GRB.BINARY, name="z")
        
        # 变量 theta: 预估的每个DMU的效率 (Continuous)
        theta = mp.addVars(self.K, lb=0.0, ub=1.0, vtype=GRB.CONTINUOUS, name="theta")
        
        # 目标: Maximize Average Theta
        mp.setObjective(theta.sum() / self.K, GRB.MAXIMIZE)
        
        # 约束: 必须选 p 个特征
        mp.addConstr(z.sum() == self.p, name="Select_p")
        
        # --- 2. 准备循环变量 ---
        global_lb = -1e10 # 全局下界 (已知的最好真实效率)
        global_ub = 1e10  # 全局上界 (主问题预估效率)
        best_z = []
        
        print("\n" + "="*80)
        print(f"{'Iter':<5} | {'Master(UB)':<12} | {'Sub(LB)':<12} | {'Gap(%)':<8} | {'Time(s)':<8} | {'Cuts(Std/Log)'}")
        print("-" * 80)
        
        for iteration in range(1, self.max_iter + 1):
            iter_start = time.time()
            
            # ==========================
            # A. 求解主问题 (Master)
            # ==========================
            mp.optimize()
            
            if mp.status != GRB.OPTIMAL:
                print("Master problem infeasible or unbounded.")
                break
            
            current_ub = mp.ObjVal
            # 获取当前的特征方案 (转换为 0/1 列表)
            z_curr = [1 if z[o].X > 0.5 else 0 for o in range(self.O)]
            # 获取当前选中的特征索引集合 S
            S_indices = [o for o in range(self.O) if z_curr[o] == 1]
            
            # ==========================
            # B. 并行求解子问题 (Subproblems)
            # ==========================
            # 构造参数任务列表
            tasks = [
                (k, self.X, self.Y, z_curr, self.K, self.I, self.O) 
                for k in range(self.K)
            ]
            
            # 启动多进程池
            with Pool(processes=self.n_jobs) as pool:
                # starmap 自动将参数解包传递给函数
                results = pool.starmap(solve_subproblem, tasks)
            
            # ==========================
            # C. 聚合结果与更新边界
            # ==========================
            total_true_efficiency = 0
            cuts_standard_needed = [] # 存储需要添加的标准割
            
            for k, res in enumerate(results):
                if res['status'] != 'Optimal':
                    # 处理极少数不可行的情况 (通常由数据质量引起)
                    # 在合成数据中很少见，这里简单给个惩罚
                    total_true_efficiency += 0
                    continue
                
                total_true_efficiency += res['obj']
                
                # 检查是否需要加 Standard Cut
                # 只有当 主问题预估值(theta) > 真实值(obj) + 误差 时才加
                if theta[k].X > res['obj'] + 1e-5:
                    cuts_standard_needed.append((k, res))
            
            current_lb = total_true_efficiency / self.K
            
            # 更新全局边界
            global_ub = min(global_ub, current_ub) # 上界非递增
            global_lb = max(global_lb, current_lb) # 下界取历史最优
            
            # 记录最佳解
            if current_lb >= global_lb - 1e-9:
                best_z = sorted(S_indices)
            
            elapsed = time.time() - start_time
            # 防止分母为0
            gap_denom = abs(global_lb) if abs(global_lb) > 1e-6 else 1.0
            gap = (global_ub - global_lb) / gap_denom
            
            # 格式化输出
            cut_info_str = f"{len(cuts_standard_needed)}/{1 if self.use_logic_cuts else 0}"
            print(f"{iteration:<5} | {current_ub:.6f}     | {current_lb:.6f}     | {gap*100:.4f}%  | {elapsed:.2f}     | {cut_info_str}")
            
            # ==========================
            # D. 收敛性检查
            # ==========================
            if gap < 1e-4:
                print(f"Converged! Gap < 0.01%")
                break
            
            if elapsed > self.time_limit:
                print(f"Time limit reached ({self.time_limit}s).")
                break
                
            # 如果没有 Standard Cut 且 Gap 还很大，说明遇到了强对偶间隙问题
            if not cuts_standard_needed and not self.use_logic_cuts:
                print("Stalled (No standard cuts found but gap exists). Enable Logic Cuts!")
                break

            # ==========================
            # E. 添加 Cuts
            # ==========================
            
            # 1. 添加 Standard Benders Cuts (Optimality Cuts)
            # ---------------------------------------------
            # Formula: theta_k <= u_k + sum( M_{ko} * w_{ko} * z_o )
            for k, res in cuts_standard_needed:
                u_val = res['u']
                w_vals = res['w']
                M_vals = res['M']
                
                # 构建线性表达式: 只包含非零项以提高效率
                expr = gp.quicksum(
                    (M_vals[o] * w_vals[o]) * z[o] 
                    for o in range(self.O)
                    if w_vals[o] > 1e-7 # 过滤极小值
                )
                mp.addConstr(theta[k] <= u_val + expr)
            
            # 2. 添加 Combinatorial Logic Cut (加强策略)
            # ---------------------------------------------
            # 原理: 如果当前组合 S 的真实效率是 current_lb。
            # 那么对于任何 S 的子集 (或偏离 S 的组合)，我们给它一个上限。
            # 为了简单且有效，我们使用全局平均效率的 Logic Cut。
            # 
            # Constraint: Avg(theta) <= current_lb + M_logic * (p - sum(z_j for j in S))
            # Meaning: 只有当你再次选满这 p 个特定的特征时，上限才是 current_lb。
            #          如果你改变了任何一个特征 (sum < p)，右边会加上 M_logic，约束失效。
            
            if self.use_logic_cuts:
                # 只有当 Master 依然过于乐观时才加
                if current_ub > current_lb + 1e-5:
                    
                    sum_z_in_S = gp.quicksum(z[j] for j in S_indices)
                    card_S = len(S_indices) # 应该等于 p
                    
                    # Logic M 只要大于可能的 Gap 即可。DEA效率差最大是1。
                    M_logic = 1.5 
                    
                    mp.addConstr(
                        (theta.sum() / self.K) <= current_lb + M_logic * (card_S - sum_z_in_S),
                        name=f"LogicCut_{iteration}"
                    )

        return {
            'status': 'Optimal' if gap < 1e-4 else 'TimeLimit',
            'obj_val': global_lb,
            'selected_features': best_z,
            'time': time.time() - start_time,
            'iterations': iteration,
            'gap': gap
        }