#ifndef DIRECTSOLVER_H
#define DIRECTSOLVER_H

#include "Config.h"
#include "DataHandler.h"
#include "Utils.h"
#include <vector>
#include <string>

// 直接求解结果结构体 (与 Benders 类似)
struct DirectResult {
    double obj;
    double gap;
    double time;
    std::string status;
    std::vector<int> features;
};

class DirectSolver {
public:
    DirectSolver(const Config& conf, const DataHandler& data, Logger* logger = nullptr);
    void solve();
    DirectResult getResult() const;

private:
    const Config& config;
    const DataHandler& data;
    Logger* logger;
    DirectResult result;
};

#endif