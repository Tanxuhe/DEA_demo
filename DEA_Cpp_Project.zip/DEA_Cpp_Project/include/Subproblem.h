#ifndef SUBPROBLEM_H
#define SUBPROBLEM_H

#include "gurobi_c++.h"
#include "DataHandler.h"
#include <vector>

// 子问题求解结果结构体
struct SubResult {
    bool feasible;
    double obj;                 // 真实效率值 (Theta_true)
    
    // Benders Cut 系数: Theta <= rhs_const + sum(rhs_coeff * z)
    // 对应公式: u_k + sum( w_ko * M_ko * z_o )
    double cut_constant;        // u_k (归一化约束的对偶值)
    std::vector<double> cut_coeffs; // w_ko * M_ko (特征约束的对偶值 * BigM)
};

class SubproblemSolver {
public:
    SubproblemSolver(const DataHandler& data, GRBEnv& env);
    ~SubproblemSolver();

    // 为特定的 DMU k 准备模型
    void setupForDMU(int k);
    
    // 求解子问题 (给定主问题的 z)
    // z_val: 主问题当前的特征选择方案 (0 或 1)
    void solve(const std::vector<double>& z_val, SubResult& res);

    // Magnanti-Wong 增强求解 (用于生成强割)
    // z_core: 核心点 (通常取 0.5 或 p/O)
    // target_efficiency: 保持原问题的最优效率值
    void solveMW(const std::vector<double>& z_val, const std::vector<double>& z_core, 
                 double target_efficiency, SubResult& res);

private:
    const DataHandler& data;
    GRBModel* model; // 乘子模型 (Primal SP)
    
    // Primal 变量 (Multiplier Form)
    std::vector<GRBVar> alpha; // 投入权重
    std::vector<GRBVar> beta;  // 产出权重
    
    // 约束引用
    GRBConstr norm_constr;     // 归一化约束
    std::vector<GRBConstr> beta_ub_constrs; // Tight Big-M 上界约束
    
    int current_k; // 当前正在计算的 DMU 索引
};

#endif