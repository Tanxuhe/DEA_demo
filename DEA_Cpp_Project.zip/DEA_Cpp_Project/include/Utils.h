#ifndef UTILS_H
#define UTILS_H

#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include "Config.h"

// 实验结果结构体
struct ExperimentResult {
    std::string method;
    int K, I, O, p;
    double obj;
    double time;
    double gap;
    int iterations;
    std::string status;
};

// 日志记录器: 负责将运行过程打印到终端并保存到文件
class Logger {
public:
    Logger(const Config& conf);
    ~Logger();

    // 记录一条信息
    void log(const std::string& message, bool to_console = true);

private:
    std::ofstream log_file;
    std::string file_path;
    
    std::string getCurrentTimestamp();
};

// 结果导出器: 负责追加 CSV 结果
class ResultExporter {
public:
    static void initCSV(const std::string& filename);
    static void appendResult(const std::string& filename, const ExperimentResult& res);
};

#endif