#ifndef BENDERSCALLBACK_H
#define BENDERSCALLBACK_H

#include "gurobi_c++.h"
#include "Config.h"
#include "DataHandler.h"
#include "Subproblem.h"
#include "Utils.h"
#include <vector>

class BendersCallback : public GRBCallback {
public:
    BendersCallback(const DataHandler& d, const Config& c, 
                    GRBVar* z_v, GRBVar* t_v, Logger* logger_ptr);
    ~BendersCallback();

    // 统计数据
    int iter_count;
    double global_best_incumbent; // 全局最佳真实效率 (LB)
    double global_best_bound;     // 全局最佳上界 (UB)
    double final_gap;

protected:
    void callback() override;

private:
    const DataHandler& data;
    const Config& config;
    GRBVar* z;
    GRBVar* theta;
    Logger* logger;

    // 并行子问题求解器
    std::vector<SubproblemSolver*> workers;
    std::vector<GRBEnv*> worker_envs;
    double start_time;
};

#endif