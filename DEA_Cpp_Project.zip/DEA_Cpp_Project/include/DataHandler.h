#ifndef DATAHANDLER_H
#define DATAHANDLER_H

#include <vector>
#include "Config.h"

class DataHandler {
public:
    DataHandler(const Config& conf);
    
    // 生成 Cobb-Douglas 模拟数据
    void generateCobbDouglas();
    
    // 数据容器
    // X[k][i]: 第 k 个 DMU 的第 i 个投入
    // Y[k][o]: 第 k 个 DMU 的第 o 个产出
    std::vector<std::vector<double>> X;
    std::vector<std::vector<double>> Y;
    
    const Config& config;

private:
    // 数据归一化 (均值归一化)
    void normalizeData();
};

#endif