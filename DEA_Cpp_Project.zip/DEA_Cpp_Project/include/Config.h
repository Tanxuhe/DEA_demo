#ifndef CONFIG_H
#define CONFIG_H

#include <string>
#include <iostream>

struct Config {
    // --- 问题规模 ---
    int K = 100;       // DMU 数量
    int I = 2;         // 投入指标数量
    int O = 20;        // 产出指标数量
    int p = 3;         // 需要选择的特征数量
    
    // --- 算法参数 ---
    double time_limit = 3600.0; // 时间限制 (秒)
    double target_gap = 0.0001; // 目标 Gap (0.01%)
    int num_threads = -1;       // 并行线程数 (-1 为自动)
    int seed = 42;              // 随机种子

    // --- 关键开关 ---
    bool use_MW = false;        // 是否开启 Magnanti-Wong 增强
    bool normalize_data = true; // 是否对数据进行均值归一化 (强烈建议开启)

    void print() const {
        std::cout << "Config: K=" << K << ", I=" << I 
                  << ", O=" << O << ", p=" << p 
                  << ", MW=" << (use_MW ? "ON" : "OFF") 
                  << ", Norm=" << (normalize_data ? "ON" : "OFF") << std::endl;
    }
};

#endif