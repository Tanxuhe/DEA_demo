#ifndef BENDERSSOLVER_H
#define BENDERSSOLVER_H

#include "Config.h"
#include "DataHandler.h"
#include "Utils.h"
#include <vector>
#include <string>

// Benders 求解结果
struct BendersResult {
    double obj;             // 目标函数值 (总效率)
    double gap;             // 最终 Gap
    double time;            // 求解时间
    int iterations;         // 迭代次数
    std::string status;     // 求解状态
    std::vector<int> features; // 选中的特征索引
};

class BendersSolver {
public:
    BendersSolver(const Config& conf, const DataHandler& data, Logger* logger = nullptr);
    ~BendersSolver();

    void solve();
    BendersResult getResult() const;

private:
    const Config& config;
    const DataHandler& data;
    Logger* logger;

    BendersResult result;
};

#endif