#include "DataHandler.h"
#include <random>
#include <cmath>
#include <iostream>
#include <numeric>

DataHandler::DataHandler(const Config& conf) : config(conf) {}

void DataHandler::generateCobbDouglas() {
    std::cout << "[Data] Generating Cobb-Douglas data..." << std::endl;
    
    std::mt19937 gen(config.seed);
    std::uniform_real_distribution<> dis(10.0, 100.0); // 基础范围

    // 1. 生成随机投入 X
    X.resize(config.K, std::vector<double>(config.I));
    for(int k=0; k<config.K; ++k) {
        for(int i=0; i<config.I; ++i) {
            X[k][i] = dis(gen);
        }
    }

    // 2. 生成产出 Y (基于 Cobb-Douglas 生产函数 + 随机噪声)
    // Y = A * prod(x^alpha)
    Y.resize(config.K, std::vector<double>(config.O));
    for(int k=0; k<config.K; ++k) {
        for(int o=0; o<config.O; ++o) {
            double production = 1.0;
            // 简单假设：每个产出只与部分投入相关，或者随机相关
            for(int i=0; i<config.I; ++i) {
                // 指数 alpha 在 0.3-0.7 之间
                double alpha = 0.5; 
                production *= std::pow(X[k][i], alpha);
            }
            // 添加一些随机性，使得有些 DMU 有效，有些无效
            double efficiency = std::uniform_real_distribution<>(0.5, 1.0)(gen); 
            Y[k][o] = production * efficiency * std::uniform_real_distribution<>(0.8, 1.2)(gen);
        }
    }

    // 3. 执行归一化 (如果配置开启)
    if (config.normalize_data) {
        normalizeData();
    }
}

void DataHandler::normalizeData() {
    std::cout << "[Data] Normalizing data (Mean Normalization)..." << std::endl;

    // 归一化 X (投入)
    for(int i=0; i<config.I; ++i) {
        double sum = 0.0;
        for(int k=0; k<config.K; ++k) sum += X[k][i];
        double mean = sum / config.K;
        if (mean > 1e-6) {
            for(int k=0; k<config.K; ++k) X[k][i] /= mean;
        }
    }

    // 归一化 Y (产出)
    for(int o=0; o<config.O; ++o) {
        double sum = 0.0;
        for(int k=0; k<config.K; ++k) sum += Y[k][o];
        double mean = sum / config.K;
        if (mean > 1e-6) {
            for(int k=0; k<config.K; ++k) Y[k][o] /= mean;
        }
    }
}