#include "BendersCallback.h"
#include <omp.h>
#include <iostream>
#include <iomanip>
#include <chrono>
#include <cmath>
#include <sstream>

static double get_wall_time() {
    using namespace std::chrono;
    return duration_cast<duration<double>>(system_clock::now().time_since_epoch()).count();
}

BendersCallback::BendersCallback(const DataHandler& d, const Config& c, 
                                 GRBVar* z_v, GRBVar* t_v, Logger* logger_ptr)
    : data(d), config(c), z(z_v), theta(t_v), logger(logger_ptr), iter_count(0) {
    
    // 初始化: Max Problem
    global_best_incumbent = -1e20; // 真实下界
    global_best_bound = 1e20;      // 理论上界
    final_gap = 1.0;
    start_time = get_wall_time();
    
    // 初始化并行环境
    int n_threads = omp_get_max_threads();
    if (config.num_threads > 0) n_threads = config.num_threads;
    omp_set_num_threads(n_threads);
    
    for(int i=0; i<n_threads; ++i) {
        GRBEnv* env = new GRBEnv(true);
        env->set(GRB_IntParam_OutputFlag, 0);
        env->set(GRB_IntParam_Threads, 1); 
        env->start();
        worker_envs.push_back(env);
        workers.push_back(new SubproblemSolver(data, *env));
    }
}

BendersCallback::~BendersCallback() {
    for(auto w : workers) delete w;
    for(auto e : worker_envs) delete e;
}

void BendersCallback::callback() {
    try {
        if (where == GRB_CB_MIPSOL) {
            // 1. 获取主问题的候选解 (Candidate Solution)
            std::vector<double> z_val(data.config.O);
            std::vector<int> selected_features;
            for(int o=0; o<data.config.O; ++o) {
                double val = getSolution(z[o]);
                if(val > 0.5) {
                    z_val[o] = 1.0;
                    selected_features.push_back(o);
                } else {
                    z_val[o] = 0.0;
                }
            }
            
            // 主问题估算的效率值 (Optimistic Estimate)
            std::vector<double> theta_est(data.config.K);
            for(int k=0; k<data.config.K; ++k) theta_est[k] = getSolution(theta[k]);
            
            // M-W 核心点: 均匀分布 (p/O)
            std::vector<double> z_core(data.config.O, (double)data.config.p / data.config.O);
            
            // 2. 并行求解子问题
            struct CutInfo { int k; double constant; std::vector<double> coeffs; };
            std::vector<CutInfo> cuts_to_add;
            double total_true_obj = 0;
            double total_est_obj = 0;
            
            #pragma omp parallel 
            {
                int tid = omp_get_thread_num();
                if (tid < workers.size()) {
                    std::vector<CutInfo> local_cuts;
                    double local_obj_sum = 0;
                    double local_est_sum = 0;
                    
                    #pragma omp for nowait
                    for(int k=0; k<data.config.K; ++k) {
                        local_est_sum += theta_est[k];
                        SubproblemSolver* worker = workers[tid];
                        SubResult res;
                        
                        worker->setupForDMU(k);
                        // A. 求解原问题 (Multiplier Model)
                        worker->solve(z_val, res);
                        
                        if (res.feasible) {
                            local_obj_sum += res.obj;
                            
                            // B. 检查冲突: Master Est > True + epsilon
                            // 如果主问题估值过高，说明需要添加约束压下来
                            if (theta_est[k] > res.obj + 1e-6) {
                                
                                // C. M-W 增强 (如果开启)
                                if (config.use_MW) {
                                    worker->solveMW(z_val, z_core, res.obj, res);
                                }
                                
                                CutInfo info;
                                info.k = k; 
                                info.constant = res.cut_constant; 
                                info.coeffs = res.cut_coeffs;
                                local_cuts.push_back(info);
                            }
                        }
                    }
                    #pragma omp critical
                    {
                        cuts_to_add.insert(cuts_to_add.end(), local_cuts.begin(), local_cuts.end());
                        total_true_obj += local_obj_sum;
                        total_est_obj += local_est_sum;
                    }
                }
            } 
            
            iter_count++;
            
            // 3. 数据维护与 Log
            double current_true_obj = total_true_obj / data.config.K;
            double current_est_obj = total_est_obj / data.config.K; // 这是 MP 当前解的目标值
            
            // Update Incumbent (Max Problem: 找更大的真实效率)
            if (current_true_obj > global_best_incumbent) {
                global_best_incumbent = current_true_obj;
            }
            
            // Update Bound (Gurobi MIP Bound)
            double current_bound = 1.0;
            try { current_bound = getDoubleInfo(GRB_CB_MIP_OBJBND); } catch (...) { 
                 // 如果获取失败，沿用旧值
                 if (global_best_bound < 2.0) current_bound = global_best_bound;
            }
            // 修正
            if (current_bound > 1.0) current_bound = 1.0;
            // Bound 不可能比 Incumbent 还差 (考虑浮点误差)
            if (current_bound < global_best_incumbent) current_bound = global_best_incumbent;
            
            global_best_bound = current_bound;

            // Gap Calculation
            double real_gap = 0.0;
            if (std::abs(global_best_incumbent) > 1e-9) 
                real_gap = std::abs(global_best_bound - global_best_incumbent) / std::abs(global_best_incumbent);
            final_gap = real_gap;

            // 打印详细日志
            std::stringstream ss;
            ss << std::left << std::setw(6) << iter_count
               << " | " << std::setw(10) << std::fixed << std::setprecision(5) << current_est_obj
               << " | " << std::setw(10) << std::fixed << std::setprecision(5) << current_true_obj
               << " | " << std::setw(10) << std::fixed << std::setprecision(5) << global_best_incumbent
               << " | " << std::setw(10) << std::fixed << std::setprecision(5) << global_best_bound
               << " | " << std::setw(9) << std::fixed << std::setprecision(4) << (real_gap * 100.0) << "%"
               << " | " << std::setw(5) << cuts_to_add.size()
               << " | [ ";
            for(int idx : selected_features) ss << idx << " ";
            ss << "]";

            if (logger) logger->log(ss.str(), true);

            // 4. 添加 Benders Cuts
            // 公式: theta[k] <= cut_constant + Sum( cut_coeffs[o] * z[o] )
            for(const auto& cut : cuts_to_add) {
                GRBLinExpr rhs_expr = cut.constant;
                for(int o=0; o<data.config.O; ++o) {
                    rhs_expr += cut.coeffs[o] * z[o];
                }
                addLazy(theta[cut.k] <= rhs_expr);
            }
        }
    } catch (GRBException e) {
        std::cout << "Error in callback: " << e.getMessage() << std::endl;
    } catch (...) {
        std::cout << "Unknown error in callback" << std::endl;
    }
}