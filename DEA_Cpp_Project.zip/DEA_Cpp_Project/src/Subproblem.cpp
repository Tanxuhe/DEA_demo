#include "Subproblem.h"
#include <cmath>
#include <algorithm>
#include <string>

SubproblemSolver::SubproblemSolver(const DataHandler& d, GRBEnv& env) 
    : data(d), model(nullptr), current_k(-1) {
    
    // --- 构建子问题: 投入导向乘子模型 (Input-Oriented Multiplier Form) ---
    // 目标: Maximize Efficiency = Sum(y_ok * beta_o)
    // s.t. Sum(x_ik * alpha_i) = 1             (归一化)
    //      Sum(y_oj * beta_o) - Sum(x_ij * alpha_i) <= 0, for all j (Peer约束)
    //      beta_o <= M_ko * z_o                (Tight Big-M 特征约束)
    //      alpha >= 0, beta >= 0

    model = new GRBModel(env);
    model->set(GRB_StringAttr_ModelName, "DEA_Multiplier_SP");
    model->set(GRB_IntParam_OutputFlag, 0); // 关闭子问题日志

    // 1. 变量定义
    alpha.resize(data.config.I);
    for(int i=0; i<data.config.I; ++i) {
        alpha[i] = model->addVar(0.0, GRB_INFINITY, 0.0, GRB_CONTINUOUS);
    }

    beta.resize(data.config.O);
    for(int o=0; o<data.config.O; ++o) {
        beta[o] = model->addVar(0.0, GRB_INFINITY, 0.0, GRB_CONTINUOUS);
    }
    
    model->update();

    // 2. 约束构建 (部分系数需要在 setupForDMU 中更新)
    
    // 归一化约束: Sum(x_ik * alpha_i) = 1
    // 先用占位系数 0.0，稍后更新
    GRBLinExpr norm_expr = 0;
    for(int i=0; i<data.config.I; ++i) norm_expr += 0.0 * alpha[i];
    norm_constr = model->addConstr(norm_expr == 1.0, "Norm");

    // Peer 约束 (对所有 DMU j)
    for(int j=0; j<data.config.K; ++j) {
        GRBLinExpr peer_expr = 0;
        for(int o=0; o<data.config.O; ++o) peer_expr += data.Y[j][o] * beta[o];
        for(int i=0; i<data.config.I; ++i) peer_expr -= data.X[j][i] * alpha[i];
        model->addConstr(peer_expr <= 0.0);
    }

    // 特征上界约束: beta_o <= M * z_o
    // 这里先添加约束结构，RHS 在 solve() 时根据 z 更新
    beta_ub_constrs.resize(data.config.O);
    for(int o=0; o<data.config.O; ++o) {
        beta_ub_constrs[o] = model->addConstr(beta[o] <= GRB_INFINITY);
    }
}

SubproblemSolver::~SubproblemSolver() {
    delete model;
}

void SubproblemSolver::setupForDMU(int k) {
    current_k = k;

    // 1. 更新目标函数: Max Sum(y_ok * beta_o)
    GRBLinExpr obj_expr = 0;
    for(int o=0; o<data.config.O; ++o) {
        obj_expr += data.Y[k][o] * beta[o];
    }
    model->setObjective(obj_expr, GRB_MAXIMIZE);

    // 2. 更新归一化约束系数: Sum(x_ik * alpha_i) = 1
    for(int i=0; i<data.config.I; ++i) {
        model->chgCoeff(norm_constr, alpha[i], data.X[k][i]);
    }
}

void SubproblemSolver::solve(const std::vector<double>& z_val, SubResult& res) {
    // 1. 根据主问题的 z 更新 beta 的上界约束
    // beta_o <= M_ko * z_o
    // 如果 z_o = 0, beta_o <= 0 (强制不选)
    // 如果 z_o = 1, beta_o <= M_ko = 1/y_ok
    
    for(int o=0; o<data.config.O; ++o) {
        double y_val = data.Y[current_k][o];
        double M_ko = (y_val > 1e-6) ? (1.0 / y_val) : 0.0;
        
        // 注意: Gurobi 浮点数处理，如果 z > 0.5 视为 1
        double rhs = (z_val[o] > 0.5) ? M_ko : 0.0;
        beta_ub_constrs[o].set(GRB_DoubleAttr_RHS, rhs);
    }

    // 2. 求解
    model->optimize();

    if (model->get(GRB_IntAttr_Status) == GRB_OPTIMAL) {
        res.feasible = true;
        res.obj = model->get(GRB_DoubleAttr_ObjVal);

        // 3. 提取 Benders Cut 系数 (核心步骤)
        // 从 LP 对偶中提取 Shadow Price (Pi)
        // Cut 公式: theta <= u_k + Sum( w_ko * M_ko * z_o )
        
        // u_k: 归一化约束的对偶值 (对应 alpha 部分)
        // 注意: Gurobi Max 问题的 Eq 约束 Pi 符号可能是负的，
        // 理论上 Dual Formulation: Min u + ...
        // 实际上 Benders Cut 的常数项就是 Pi 值本身。
        res.cut_constant = norm_constr.get(GRB_DoubleAttr_Pi);

        res.cut_coeffs.resize(data.config.O);
        for(int o=0; o<data.config.O; ++o) {
            // w_ko: 特征上界约束 (beta <= RHS) 的对偶值
            // Max 问题，<= 约束的 Pi 应该非负。代表放宽 RHS 能带来多少收益。
            double w_ko = beta_ub_constrs[o].get(GRB_DoubleAttr_Pi);
            
            // 计算 M_ko
            double y_val = data.Y[current_k][o];
            double M_ko = (y_val > 1e-6) ? (1.0 / y_val) : 0.0;
            
            // Cut 系数 = w_ko * M_ko
            res.cut_coeffs[o] = w_ko * M_ko;
        }

    } else {
        // 如果不可行 (通常不会发生，除非数据全是0)，设置默认值
        res.feasible = false;
        res.obj = 0.0;
    }
}

// --- Magnanti-Wong 增强求解 (显式构建对偶模型) ---
void SubproblemSolver::solveMW(const std::vector<double>& z_val, const std::vector<double>& z_core, 
                               double target_efficiency, SubResult& res) {
    
    // 我们需要构建 SP 的对偶模型 (Dual of SP)
    // SP 是 Multiplier Form (Max), 所以它的 Dual 类似于 Envelopment Form (Min).
    // 
    // SP Dual Variables:
    //   gamma (free): 对应 SP 的 Norm 约束 (sum x alpha = 1)
    //   lambda_j >= 0: 对应 SP 的 Peer 约束 (beta Y - alpha X <= 0)
    //   pi_o >= 0:     对应 SP 的 Bound 约束 (beta <= M z)
    //
    // Dual Constraints (对应 SP 的变量 alpha, beta):
    //   对 alpha_i: gamma * x_ik - sum_j (lambda_j * x_ij) >= 0
    //   对 beta_o:  sum_j (lambda_j * y_oj) - pi_o >= y_ok (系数是Obj中的y_ok)
    //
    // Dual Objective (Standard): Min gamma + sum_o (pi_o * M * z_val)
    // M-W Objective: Minimize Cut value at z_core
    //             => Min gamma + sum_o (pi_o * M * z_core)
    // Constraint: Original Dual Obj <= target_efficiency (保持最优性)

    GRBModel mw_model(model->getEnv());
    mw_model.set(GRB_IntParam_OutputFlag, 0);

    // 1. 变量定义
    GRBVar gamma = mw_model.addVar(-GRB_INFINITY, GRB_INFINITY, 0.0, GRB_CONTINUOUS, "gamma");
    std::vector<GRBVar> lambda(data.config.K);
    for(int j=0; j<data.config.K; ++j) lambda[j] = mw_model.addVar(0.0, GRB_INFINITY, 0.0, GRB_CONTINUOUS);
    std::vector<GRBVar> pi(data.config.O);
    for(int o=0; o<data.config.O; ++o) pi[o] = mw_model.addVar(0.0, GRB_INFINITY, 0.0, GRB_CONTINUOUS);

    mw_model.update();

    // 2. 约束 (Dual Constraints)
    // 对应 alpha_i: gamma * X_ik >= Sum(lambda_j * X_ij)
    for(int i=0; i<data.config.I; ++i) {
        GRBLinExpr rhs = 0;
        for(int j=0; j<data.config.K; ++j) rhs += lambda[j] * data.X[j][i];
        mw_model.addConstr(gamma * data.X[current_k][i] >= rhs);
    }

    // 对应 beta_o: Sum(lambda_j * Y_oj) - pi_o >= Y_ok
    for(int o=0; o<data.config.O; ++o) {
        GRBLinExpr lhs = 0;
        for(int j=0; j<data.config.K; ++j) lhs += lambda[j] * data.Y[j][o];
        mw_model.addConstr(lhs + pi[o] >= data.Y[current_k][o]);
    }

    // 3. 保持最优性 (Optimal Face Constraint)
    // 当前的 Cut 值 (在 z_val 处) 必须等于 target_efficiency
    GRBLinExpr current_cut_val = gamma;
    for(int o=0; o<data.config.O; ++o) {
        double y_val = data.Y[current_k][o];
        double M = (y_val > 1e-6) ? (1.0 / y_val) : 0.0;
        // 如果 z_val[o]=1, 这一项存在；如果=0，为0
        if (z_val[o] > 0.5) {
            current_cut_val += pi[o] * M;
        }
    }
    // Min问题，保持最优意味着 <= target (其实是 ==)
    mw_model.addConstr(current_cut_val <= target_efficiency + 1e-6);

    // 4. M-W 目标: Minimize Cut value at z_core
    GRBLinExpr mw_obj = gamma;
    for(int o=0; o<data.config.O; ++o) {
        double y_val = data.Y[current_k][o];
        double M = (y_val > 1e-6) ? (1.0 / y_val) : 0.0;
        mw_obj += pi[o] * M * z_core[o];
    }
    mw_model.setObjective(mw_obj, GRB_MINIMIZE);

    // 5. 求解
    mw_model.optimize();

    if (mw_model.get(GRB_IntAttr_Status) == GRB_OPTIMAL) {
        // M-W 成功，提取更优的对偶解
        res.feasible = true;
        res.obj = target_efficiency;

        // gamma 对应 cut_constant
        res.cut_constant = gamma.get(GRB_DoubleAttr_X);

        res.cut_coeffs.resize(data.config.O);
        for(int o=0; o<data.config.O; ++o) {
            // pi_o * M 对应 cut_coeffs
            double pi_val = pi[o].get(GRB_DoubleAttr_X);
            double y_val = data.Y[current_k][o];
            double M = (y_val > 1e-6) ? (1.0 / y_val) : 0.0;
            res.cut_coeffs[o] = pi_val * M;
        }
    } else {
        // 如果 M-W 求解失败 (数值问题)，静默返回，保留 solve() 的结果
    }
}