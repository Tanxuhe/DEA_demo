#include "Utils.h"
#include <sys/stat.h>
#include <chrono>
#include <ctime>

#if defined(_WIN32)
    #include <direct.h>
    #define MKDIR(path) _mkdir(path)
#else
    #include <sys/types.h>
    #include <sys/stat.h>
    #define MKDIR(path) mkdir(path, 0755)
#endif

// --- Logger 实现 ---
Logger::Logger(const Config& conf) {
    // 创建 logs 目录
    MKDIR("logs");

    // 生成带参数和时间戳的文件名
    std::stringstream ss;
    ss << "logs/Exp_K" << conf.K 
       << "_O" << conf.O 
       << "_p" << conf.p 
       << (conf.use_MW ? "_MW" : "_NoMW") 
       << "_" << getCurrentTimestamp() << ".log";
    
    file_path = ss.str();
    log_file.open(file_path);

    if (log_file.is_open()) {
        log_file << "========== Experiment Log Start ==========\n";
        conf.print(); // 记录配置
        log_file << "------------------------------------------\n";
        // 打印详细表头
        log_file << std::left << std::setw(6) << "Iter"
                 << " | " << std::setw(10) << "Mast(Est)" // 主问题估计值 (UB的一部分)
                 << " | " << std::setw(10) << "Sub(True)" // 真实值
                 << " | " << std::setw(10) << "Best_LB"   // Incumbent (真实下界)
                 << " | " << std::setw(10) << "Best_UB"   // Bound (理论上界)
                 << " | " << std::setw(9)  << "Gap(%)"
                 << " | " << std::setw(5)  << "Cuts"
                 << " | " << "Features" << "\n";
    }
}

Logger::~Logger() {
    if (log_file.is_open()) log_file.close();
}

void Logger::log(const std::string& message, bool to_console) {
    if (log_file.is_open()) {
        log_file << message << std::endl;
        log_file.flush();
    }
    if (to_console) {
        std::cout << message << std::endl;
    }
}

std::string Logger::getCurrentTimestamp() {
    auto now = std::chrono::system_clock::now();
    std::time_t now_time = std::chrono::system_clock::to_time_t(now);
    std::tm* local_tm = std::localtime(&now_time);
    
    std::stringstream ss;
    ss << (1900 + local_tm->tm_year)
       << std::setfill('0') << std::setw(2) << (1 + local_tm->tm_mon)
       << std::setw(2) << local_tm->tm_mday << "_"
       << std::setw(2) << local_tm->tm_hour
       << std::setw(2) << local_tm->tm_min
       << std::setw(2) << local_tm->tm_sec;
    return ss.str();
}

// --- ResultExporter 实现 ---
void ResultExporter::initCSV(const std::string& filename) {
    struct stat buffer;
    bool fileExists = (stat(filename.c_str(), &buffer) == 0);
    if (!fileExists) {
        std::ofstream file(filename);
        file << "Method,K,I,O,p,MW,Obj,Time(s),Gap(%),Iterations,Status\n";
        file.close();
    }
}

void ResultExporter::appendResult(const std::string& filename, const ExperimentResult& res) {
    std::ofstream file(filename, std::ios::app);
    if (file.is_open()) {
        file << res.method << "," << res.K << "," << res.I << "," 
             << res.O << "," << res.p << "," 
             // 这里我们可以根据 method 名字判断是否开启了 MW，简单起见留空或填 -
             "-" << "," 
             << res.obj << "," << res.time << "," << res.gap * 100.0 << "," 
             << res.iterations << "," << res.status << "\n";
        file.close();
        std::cout << "[Utils] Result saved to " << filename << std::endl;
    }
}