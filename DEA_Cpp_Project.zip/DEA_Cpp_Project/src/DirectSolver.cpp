#include "DirectSolver.h"
#include "gurobi_c++.h"
#include <iostream>

DirectSolver::DirectSolver(const Config& c, const DataHandler& d, Logger* l)
    : config(c), data(d), logger(l) {}

void DirectSolver::solve() {
    try {
        if(logger) logger->log(">>> Starting Direct Solver (MILP Baseline)...");

        GRBEnv env;
        // [可选] 如果你想看 Gurobi 原生日志，把这里改成 1
        env.set(GRB_IntParam_OutputFlag, 0); 
        env.start();

        GRBModel model(env);
        model.set(GRB_StringAttr_ModelName, "Direct_MILP");

        // --- 1. 变量定义 ---
        GRBVar* z = model.addVars(config.O, GRB_BINARY);
        
        std::vector<std::vector<GRBVar>> alpha(config.K, std::vector<GRBVar>(config.I));
        std::vector<std::vector<GRBVar>> beta(config.K, std::vector<GRBVar>(config.O));

        for(int k=0; k<config.K; ++k) {
            for(int i=0; i<config.I; ++i) {
                alpha[k][i] = model.addVar(0.0, GRB_INFINITY, 0.0, GRB_CONTINUOUS);
            }
            for(int o=0; o<config.O; ++o) {
                beta[k][o] = model.addVar(0.0, GRB_INFINITY, 0.0, GRB_CONTINUOUS);
            }
        }

        // --- 2. 目标函数: Maximize Average Efficiency ---
        GRBLinExpr total_obj = 0;
        for(int k=0; k<config.K; ++k) {
            GRBLinExpr eff_k = 0;
            for(int o=0; o<config.O; ++o) {
                eff_k += data.Y[k][o] * beta[k][o];
            }
            total_obj += eff_k;
        }
        // [修改] 除以 K，使用平均值
        model.setObjective(total_obj / config.K, GRB_MAXIMIZE);

        // --- 3. 约束 ---
        
        // A. Cardinality
        GRBLinExpr sum_z = 0;
        for(int o=0; o<config.O; ++o) sum_z += z[o];
        model.addConstr(sum_z == config.p, "Card");

        // B. DEA Constraints
        for(int k=0; k<config.K; ++k) {
            // Normalization
            GRBLinExpr norm = 0;
            for(int i=0; i<config.I; ++i) norm += data.X[k][i] * alpha[k][i];
            model.addConstr(norm == 1.0);

            // Peer Constraints
            for(int j=0; j<config.K; ++j) {
                GRBLinExpr peer = 0;
                for(int o=0; o<config.O; ++o) peer += data.Y[j][o] * beta[k][o];
                for(int i=0; i<config.I; ++i) peer -= data.X[j][i] * alpha[k][i];
                model.addConstr(peer <= 0.0);
            }

            // Tight Big-M
            for(int o=0; o<config.O; ++o) {
                double M_ko = (data.Y[k][o] > 1e-6) ? (1.0 / data.Y[k][o]) : 0.0;
                model.addConstr(beta[k][o] <= M_ko * z[o]);
            }
        }

        // --- 4. 参数 ---
        model.set(GRB_DoubleParam_TimeLimit, config.time_limit);
        model.set(GRB_DoubleParam_MIPGap, config.target_gap);
        if (config.num_threads > 0) model.set(GRB_IntParam_Threads, config.num_threads);

        if(logger) logger->log("[Direct] Optimization Started...");
        
        model.optimize();

        // --- 5. 结果 ---
        result.time = model.get(GRB_DoubleAttr_Runtime);
        int status = model.get(GRB_IntAttr_Status);
        
        if (model.get(GRB_IntAttr_SolCount) > 0) {
            result.obj = model.get(GRB_DoubleAttr_ObjVal);
            result.gap = model.get(GRB_DoubleAttr_MIPGap);
            
            result.features.clear();
            for(int o=0; o<config.O; ++o) {
                if (z[o].get(GRB_DoubleAttr_X) > 0.5) result.features.push_back(o);
            }
        } else {
            result.obj = 0.0;
            result.gap = 1.0;
        }

        if (status == GRB_OPTIMAL) result.status = "Optimal";
        else if (status == GRB_TIME_LIMIT) result.status = "TimeLimit";
        else result.status = "Other";

        delete[] z;

    } catch (GRBException e) {
        if(logger) logger->log("Direct Solver Error: " + e.getMessage());
    }
}

DirectResult DirectSolver::getResult() const {
    return result;
}