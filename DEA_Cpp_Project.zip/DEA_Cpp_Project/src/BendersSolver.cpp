#include "BendersSolver.h"
#include "BendersCallback.h"
#include "gurobi_c++.h"
#include <iostream>

BendersSolver::BendersSolver(const Config& c, const DataHandler& d, Logger* l) 
    : config(c), data(d), logger(l) {}

BendersSolver::~BendersSolver() {}

void BendersSolver::solve() {
    try {
        if(logger) logger->log(">>> Starting Benders Solver (Tight Big-M + Input Oriented)...");
        
        GRBEnv env;
        env.set(GRB_IntParam_OutputFlag, 0); 
        env.start();

        GRBModel master(env);
        master.set(GRB_StringAttr_ModelName, "Master");

        // --- 1. 变量定义 ---
        GRBVar* z = master.addVars(config.O, GRB_BINARY);
        GRBVar* theta = master.addVars(config.K, GRB_CONTINUOUS);
        for(int k=0; k<config.K; ++k) {
            theta[k].set(GRB_DoubleAttr_LB, 0.0);
            theta[k].set(GRB_DoubleAttr_UB, 1.0);
        }

        // --- 2. 目标函数: Maximize Average Efficiency ---
        // [修改] 除以 K，使用平均值
        GRBLinExpr obj_expr = 0;
        for(int k=0; k<config.K; ++k) obj_expr += theta[k];
        master.setObjective(obj_expr / config.K, GRB_MAXIMIZE);

        // --- 3. 约束 ---
        GRBLinExpr sum_z = 0;
        for(int o=0; o<config.O; ++o) sum_z += z[o];
        master.addConstr(sum_z == config.p, "Cardinality");

        // --- 4. 参数 ---
        master.set(GRB_IntParam_LazyConstraints, 1);
        master.set(GRB_DoubleParam_TimeLimit, config.time_limit);
        master.set(GRB_DoubleParam_MIPGap, config.target_gap);
        if (config.num_threads > 0) master.set(GRB_IntParam_Threads, config.num_threads);

        BendersCallback cb(data, config, z, theta, logger);
        master.setCallback(&cb);

        if(logger) logger->log("[Benders] Optimization Started...");
        
        master.optimize();

        // --- 5. 结果存储 (关键修复) ---
        int status = master.get(GRB_IntAttr_Status);
        
        // [修复] 始终优先使用 Callback 中记录的 global_best_incumbent
        // 因为 Master Obj 可能是过期的（未被 Cut 更新的）值，或者是 Sum 形式
        // Callback 中的 incumbent 已经是 Average 形式，且是最新的
        result.obj = cb.global_best_incumbent;
        
        // Gap 也使用 Callback 最终计算的
        result.gap = cb.final_gap;
        
        result.iterations = cb.iter_count;
        result.time = master.get(GRB_DoubleAttr_Runtime);

        if (status == GRB_OPTIMAL) result.status = "Optimal";
        else if (status == GRB_TIME_LIMIT) result.status = "TimeLimit";
        else result.status = "Other";

        // 提取选中的特征
        result.features.clear();
        // 这里依然从 Gurobi 变量中提取 z，因为 Gurobi 最终会收敛到该解
        // 如果 Gurobi 没找到解，则为空
        if (master.get(GRB_IntAttr_SolCount) > 0) {
            for(int o=0; o<config.O; ++o) {
                if (z[o].get(GRB_DoubleAttr_X) > 0.5) {
                    result.features.push_back(o);
                }
            }
        }
        
        delete[] z;
        delete[] theta;

    } catch (GRBException e) {
        if(logger) logger->log("Gurobi Error: " + e.getMessage());
    }
}

BendersResult BendersSolver::getResult() const {
    return result;
}