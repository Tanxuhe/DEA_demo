#include "Config.h"
#include "DataHandler.h"
#include "BendersSolver.h"
#include "DirectSolver.h"
#include "Utils.h"
#include <iostream>
#include <vector>

int main() {
    try {
        std::string csv_file = "Validation_Results.csv"; 
        ResultExporter::initCSV(csv_file);

        // --- 实验配置 ---
        int K_fixed = 150; // 你可以根据需要调整规模，比如 100, 300
        int I_fixed = 2;
        int O_fixed = 20; 
        int p_fixed = 5;   
        
        Config conf;
        conf.K = K_fixed; 
        conf.I = I_fixed; 
        conf.O = O_fixed; 
        conf.p = p_fixed;
        conf.time_limit = 900; // 给足时间，观察收敛
        conf.target_gap = 0.0001;
        conf.seed = 42; 
        conf.normalize_data = true; // 始终开启归一化

        Logger logger(conf);
        logger.log(">>> Comparative Experiment: Benders(MW) vs Benders(Std) vs Direct");

        // 生成数据 (所有方法使用同一份数据)
        DataHandler data(conf);
        data.generateCobbDouglas();

        // ==========================================
        // 1. 运行 Benders Solver (开启 MW)
        // ==========================================
        {
            // [关键] 开启 MW
            conf.use_MW = true; 
            
            logger.log("\n>>> [1/3] Running Benders Solver (With MW)...");
            // 注意：传入的是当前的 conf (use_MW=true)
            BendersSolver solver(conf, data, &logger); 
            solver.solve();
            BendersResult res = solver.getResult();

            std::stringstream ss;
            ss << "[Benders MW] Obj: " << res.obj 
               << ", Time: " << res.time << "s"
               << ", Iter: " << res.iterations;
            logger.log(ss.str());
            
            ExperimentResult csv_res;
            csv_res.method = "Benders_MW"; // 标记为 MW
            csv_res.K = K_fixed; csv_res.I = I_fixed; csv_res.O = O_fixed; csv_res.p = p_fixed;
            csv_res.obj = res.obj;
            csv_res.time = res.time;
            csv_res.gap = res.gap;
            csv_res.iterations = res.iterations;
            csv_res.status = res.status;
            ResultExporter::appendResult(csv_file, csv_res);
        }

        // ==========================================
        // 2. 运行 Benders Solver (标准/无 MW)
        // ==========================================
        {
            // [关键] 关闭 MW
            conf.use_MW = false;

            logger.log("\n>>> [2/3] Running Benders Solver (Standard - No MW)...");
            // 重新实例化 Solver，传入更新后的 conf
            BendersSolver solver(conf, data, &logger); 
            solver.solve();
            BendersResult res = solver.getResult();

            std::stringstream ss;
            ss << "[Benders Std] Obj: " << res.obj 
               << ", Time: " << res.time << "s"
               << ", Iter: " << res.iterations;
            logger.log(ss.str());
            
            ExperimentResult csv_res;
            csv_res.method = "Benders_Std"; // 标记为 Standard
            csv_res.K = K_fixed; csv_res.I = I_fixed; csv_res.O = O_fixed; csv_res.p = p_fixed;
            csv_res.obj = res.obj;
            csv_res.time = res.time;
            csv_res.gap = res.gap;
            csv_res.iterations = res.iterations;
            csv_res.status = res.status;
            ResultExporter::appendResult(csv_file, csv_res);
        }

        // ==========================================
        // 3. 运行 Direct Solver (MILP Baseline)
        // ==========================================
        {
            // Direct Solver 不受 use_MW 参数影响，但为了日志整洁，保持配置
            conf.use_MW = false; 

            logger.log("\n>>> [3/3] Running Direct Solver (MILP)...");
            DirectSolver solver(conf, data, &logger);
            solver.solve();
            DirectResult res = solver.getResult();

            std::stringstream ss;
            ss << "[Direct Result] Obj: " << res.obj 
               << ", Time: " << res.time << "s";
            logger.log(ss.str());

            ExperimentResult csv_res;
            csv_res.method = "Direct_MILP";
            csv_res.K = K_fixed; csv_res.I = I_fixed; csv_res.O = O_fixed; csv_res.p = p_fixed;
            csv_res.obj = res.obj;
            csv_res.time = res.time;
            csv_res.gap = res.gap;
            csv_res.iterations = 0; // Direct 没有外部迭代
            csv_res.status = res.status;
            ResultExporter::appendResult(csv_file, csv_res);
        }

        logger.log("\n========== All Experiments Completed ==========");

    } catch (std::exception& e) {
        std::cerr << "[Main Exception] " << e.what() << std::endl;
        return 1;
    }

    return 0;
}